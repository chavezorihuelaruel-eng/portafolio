const express = require("express");
const multer = require("multer");
const sqlite3 = require("sqlite3").verbose();
const session = require("express-session");

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static("public"));
app.use("/uploads", express.static("uploads"));

app.use(session({
    secret: "123",
    resave: false,
    saveUninitialized: true
}));

const db = new sqlite3.Database("./database.db");

db.run(`
CREATE TABLE IF NOT EXISTS trabajos (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 semana TEXT,
 titulo TEXT,
 archivo TEXT
)
`);

const storage = multer.diskStorage({
 destination: "uploads/",
 filename: (req, file, cb) => {
   cb(null, Date.now() + "-" + file.originalname);
 }
});

const upload = multer({ storage });

app.post("/login", (req, res) => {
    const { correo, password } = req.body;

    if(correo === "admin" && password === "1234"){
        req.session.user = true;
        res.send("ok");
    } else {
        res.send("error");
    }
});

app.post("/upload", upload.single("archivo"), (req, res) => {
    if (!req.session.user) {
        return res.send("No autorizado");
    }

    const { semana, titulo } = req.body;
    const archivo = req.file.filename;

    db.run(
        "INSERT INTO trabajos (semana, titulo, archivo) VALUES (?, ?, ?)",
        [semana, titulo, archivo]
    );

    res.redirect("/");
});

app.get("/trabajos", (req, res) => {
    db.all("SELECT * FROM trabajos", [], (err, rows) => {
        res.json(rows);
    });
});

app.listen(3000, () => console.log("http://localhost:3000"));
